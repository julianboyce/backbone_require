# backbone_require
BackboneJS + Parse + RequireJS
